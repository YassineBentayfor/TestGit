package Abstract_factory;

import java.util.Date;

public interface Factory {
    Vehicule createVehicule();
}
