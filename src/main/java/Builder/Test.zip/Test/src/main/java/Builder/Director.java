package Builder;

public class Director {
    public Builder makeSUV(Builder builder){
        builder.reset();
        builder.setSeats(2);
        builder.setEngine("TOYOTA");
        builder.setTripComputer(Boolean.TRUE);
        builder.setGPS(Boolean.FALSE);
        return builder;
    }

    public Builder makeSports(Builder builder){
        builder.reset();
        builder.setSeats(4);
        builder.setEngine("HONDA");
        builder.setTripComputer(Boolean.TRUE);
        builder.setGPS(Boolean.TRUE);
        return builder;
    }
}
