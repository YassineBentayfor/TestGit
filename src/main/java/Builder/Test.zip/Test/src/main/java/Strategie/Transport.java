package Strategie;

public interface Transport {
    public double cost(Cargo cargo);
}
