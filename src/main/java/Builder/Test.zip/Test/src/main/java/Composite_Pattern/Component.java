package Composite_Pattern;

public interface Component {
    void render();
    void move();

}
