package Strategie.better;

public interface Flyable {
    public void Fly(Duck duck);
}
