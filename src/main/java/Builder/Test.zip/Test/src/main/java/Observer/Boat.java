package Observer;

public class Boat {
    String poid;

    public Boat(String mark) {
        this.poid = mark;
    }
    public Boat() {}
}
