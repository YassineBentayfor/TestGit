package Observer;

public interface Publisher {
    public void addAll();
    public void remove(Observer observer);


}
