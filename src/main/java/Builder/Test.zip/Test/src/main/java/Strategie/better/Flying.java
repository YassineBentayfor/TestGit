package Strategie.better;

public class Flying implements Flyable{
    @Override
    public void Fly(Duck duck) {
        System.out.println("OUIIIIIIIIIIIIIIIIII");
    }
}
