package Observer;


public class Voiture {
    String mark;

    public Voiture(String mark) {
        this.mark = mark;
    }
    public Voiture() {}

}
