package Abstract_factory;

public class Test {
}
