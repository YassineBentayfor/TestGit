package Adapter;

public interface Filter {
    void apply(Image image);

}
