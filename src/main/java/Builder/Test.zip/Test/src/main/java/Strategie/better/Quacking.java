package Strategie.better;

public class Quacking implements Quackable{

    @Override
    public void Quackable(Duck duck) {
        System.out.println("QUACK QUACK QUACK !!!");
    }
}
