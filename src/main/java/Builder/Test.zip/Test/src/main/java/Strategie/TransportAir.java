package Strategie;

public class TransportAir implements Transport{
    @Override
    public double cost(Cargo cargo) {
        return 0;
    }
}
