package Strategie.better;

public class MatterDuck extends Duck{
    public MatterDuck(Quackable quackable, Flyable flyable) {
        super(quackable, flyable);
    }
}
