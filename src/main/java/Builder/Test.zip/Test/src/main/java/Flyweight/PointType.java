package Flyweight;

public enum PointType {
    Hospital,
    Cafe,
    restaurant
}
