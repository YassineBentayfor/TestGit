package Fascade;

public class Connection {
    public void disconnect(){

    }
}
