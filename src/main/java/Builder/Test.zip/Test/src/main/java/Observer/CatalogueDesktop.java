package Observer;

public class CatalogueDesktop implements Observer {
    @Override
    public void update(Publisher publisher) {

    }
}
