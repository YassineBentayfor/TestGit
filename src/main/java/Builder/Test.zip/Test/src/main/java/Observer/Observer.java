package Observer;

public interface Observer {
    void update(Publisher publisher);
}
