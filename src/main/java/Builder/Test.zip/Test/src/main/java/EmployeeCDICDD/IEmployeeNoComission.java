package EmployeeCDICDD;

public interface IEmployeeNoComission {
    public double calculerSalaireNet();

}
