package observerWeather;

public class Publisher {
}
