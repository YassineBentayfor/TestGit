package EmployeeCDICDD;

public class Employee {
    private String name;
    private double SalairedeBase;

    public void blabla(){
        System.out.println("AAAAAAAAAAAAAAAAAAAA");
    }

    public String getName() {
        return name;
    }

    public double getSalairedeBase() {
        return SalairedeBase;
    }
}
