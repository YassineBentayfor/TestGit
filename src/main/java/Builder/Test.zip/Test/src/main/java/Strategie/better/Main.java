package Strategie.better;

public class Main {
    public static void main(String [] args){
        RubberDuck rubberDuck = new RubberDuck();
    }
}
