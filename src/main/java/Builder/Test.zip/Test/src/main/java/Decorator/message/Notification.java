package Decorator.message;

public interface Notification {
    public void sendMessage(String data);
}
