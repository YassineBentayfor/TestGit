package Observer;

public class CatalogueWeb implements Observer{
    @Override
    public void update(Publisher publisher) {

    }
}
