package Strategie.better;

public interface Quackable {
    public void Quackable(Duck duck);



}
