package EmployeeCDICDD;

public class Main {
    public static void main(String [] args){
        IEmployeeCommition e = new EmployeeCDD();
    }
}
