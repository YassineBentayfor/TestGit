package Strategie;

public class TransportRoute implements Transport{
    @Override
    public double cost(Cargo cargo) {
        return 0;
    }
}
