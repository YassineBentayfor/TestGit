package Adapter;

public class Image {
}
