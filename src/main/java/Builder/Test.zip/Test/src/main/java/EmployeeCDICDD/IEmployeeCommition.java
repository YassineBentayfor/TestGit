package EmployeeCDICDD;

public interface IEmployeeCommition extends IEmployeeNoComission{
    public double calculerCommition();
}
