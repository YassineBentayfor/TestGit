package Observer;

public class CatalogueMobile implements Observer{
    @Override
    public void update(Publisher publisher) {

    }
}
