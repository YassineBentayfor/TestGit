package Fascade;

public class AuthToken {
}
