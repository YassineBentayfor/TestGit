package Decorator;

public interface Stream {
    void write(String data);
}
