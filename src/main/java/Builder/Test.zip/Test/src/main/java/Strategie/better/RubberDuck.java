package Strategie.better;

public class RubberDuck extends Duck{

    public RubberDuck() {
        super();
    }

    public RubberDuck(Quackable quackable, Flyable flyable) {
        super(quackable, flyable);
    }
}
